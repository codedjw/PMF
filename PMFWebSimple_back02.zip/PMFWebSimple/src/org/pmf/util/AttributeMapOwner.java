package org.pmf.util;

public interface AttributeMapOwner {
	
	AttributeMap getAttributeMap();
	
}
