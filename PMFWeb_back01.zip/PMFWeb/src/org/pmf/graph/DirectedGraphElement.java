package org.pmf.graph;

public interface DirectedGraphElement {
	
	String getLabel();

}
